from datetime import datetime
import io
import logging

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

from config import DRIVE_FOLDER_ID

logger = logging.getLogger(__name__)

# مسار ملف مفتاح حساب الخدمة والنطاقات المطلوبة
SERVICE_ACCOUNT_FILE = r"C:\Users\sexee\Desktop\quran-478116-2460877d3618.json"
SCOPES = ["https://www.googleapis.com/auth/drive"]

# كاش لحفظ كائن الخدمة وتجنب إعادة بناء الاتصال في كل طلب
_DRIVE_SERVICE_CACHE = None


def get_drive_service():
    """ينشئ أو يعيد اتصالًا مستقرًا مع Google Drive API باستخدام Service Account."""
    global _DRIVE_SERVICE_CACHE

    if _DRIVE_SERVICE_CACHE is None:
        credentials = service_account.Credentials.from_service_account_file(
            SERVICE_ACCOUNT_FILE,
            scopes=SCOPES,
        )
        _DRIVE_SERVICE_CACHE = build("drive", "v3", credentials=credentials)

    return _DRIVE_SERVICE_CACHE


def test_connection():
    """يتحقق من إمكانية الاتصال بـ Google Drive باستخدام حساب الخدمة."""
    try:
        service = get_drive_service()
        service.about().get(fields="user").execute()
        return True
    except Exception as e:
        logger.exception(e)
        return False


def count_videos():
    """يعيد عدد الملفات الموجودة داخل مجلد Drive المحدد."""
    service = get_drive_service()
    query = f"'{DRIVE_FOLDER_ID}' in parents and trashed=false"

    files = []
    page_token = None

    while True:
        response = service.files().list(
            q=query,
            fields="nextPageToken,files(id)",
            pageToken=page_token,
        ).execute()

        files.extend(response.get("files", []))
        page_token = response.get("nextPageToken")

        if not page_token:
            break

    return len(files)


def list_videos():
    """يعيد قائمة بملفات الفيديو مرتبة من الأحدث إلى الأقدم مع تاريخ منسق وجاهز."""
    service = get_drive_service()
    query = (
        f"'{DRIVE_FOLDER_ID}' in parents "
        "and trashed=false "
        "and mimeType contains 'video/'"
    )

    files = []
    page_token = None

    # تم التعديل هنا: دمج الحقول في سطر واحد بدون مسافات أو أسطر جديدة
    FIELDS = "nextPageToken,files(id,name,mimeType,size,createdTime)"

    while True:
        response = service.files().list(
            q=query,
            orderBy="createdTime desc",
            fields=FIELDS,
            pageToken=page_token,
        ).execute()

        files.extend(response.get("files", []))
        page_token = response.get("nextPageToken")

        if not page_token:
            break

    # إضافة حقل التاريخ المنسق بشكل جميل لكل ملف فيديو داخل القائمة
    for file in files:
        if "createdTime" in file:
            dt = datetime.fromisoformat(
                file["createdTime"].replace("Z", "+00:00")
            )
            file["created"] = dt.strftime("%Y-%m-%d")

    return files


def get_video_info(file_id):
    """يعيد معلومات ملف فيديو واحد مع حقل التاريخ المنسق."""
    service = get_drive_service()
    
    # تم التعديل هنا: دمج الحقول لمنع أخطاء Google API
    info = service.files().get(
        fileId=file_id,
        fields="id,name,mimeType,size,createdTime",
    ).execute()

    # تنسيق التاريخ للملف المفرد أيضاً لتوحيد التجربة
    if "createdTime" in info:
        dt = datetime.fromisoformat(
            info["createdTime"].replace("Z", "+00:00")
        )
        info["created"] = dt.strftime("%Y-%m-%d")

    return info


def download_video(file_id):
    """يحمّل ملف فيديو من Drive ويعيده كـ BytesIO."""
    service = get_drive_service()
    request = service.files().get_media(fileId=file_id)

    buffer = io.BytesIO()
    downloader = MediaIoBaseDownload(buffer, request)

    done = False
    while not done:
        _, done = downloader.next_chunk()

    buffer.seek(0)
    return buffer


def delete_video(file_id):
    service = get_drive_service()

    try:
        # التأكد من وجود الملف
        info = service.files().get(
            fileId=file_id,
            fields="id,name,trashed"
        ).execute()

        logger.info(f"قبل الحذف: {info}")

        # حذف
        service.files().delete(
            fileId=file_id,
            supportsAllDrives=True
        ).execute()

        # التأكد بعد الحذف
        try:
            service.files().get(
                fileId=file_id,
                fields="id,name"
            ).execute()

            logger.error("الملف مازال موجوداً بعد الحذف!")
            return False

        except Exception:
            logger.info("تم حذف الملف فعلاً")
            return True

    except Exception as e:
        logger.exception(f"فشل حذف الملف {file_id}: {e}")
        return False


# ---------- دوال مساعدة إضافية ----------

def format_size(size):
    """يحول حجم الملف بالبايت إلى صيغة مقروءة للبشر (KB, MB, GB)."""
    size = int(size)
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0

    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1

    if i == 0:
        return f"{int(size)} {units[i]}"

    return f"{size:.1f} {units[i]}"


def format_date(created_time):
    """دالة احتياطية لتحويل صيغة تاريخ ISO يدوياً عند الحاجة خارج القوائم."""
    dt = datetime.fromisoformat(
        created_time.replace("Z", "+00:00")
    )
    return dt.strftime("%Y-%m-%d")
